$(document).ready(function(){
	$("#on").click (function(event){
		if($(".menu").is(":hidden")){
			$(".menu").show();
		} else{
		$(".menu").hide();
	}
	
	event.stopPropagation();
	});
	
	$("#clip").click (function(cli){
		if($(".clip").is(":hidden")){
			$(".clip").show();
		$(".hat-clik").hide();
		} else{
		$(".clip").hide();
	}
	
	cli.stopPropagation();
	});
	
	$("body").click (function(){
		if($(".clip").is(":visible")){
			$(".clip").hide();
		}
	});
	
	
	$("#hat-clik").click (function(hatt){
		if($(".hat-clik").is(":hidden")){
			$(".hat-clik").show();
		$(".clip").hide();
		} else{
		$(".hat-clik").hide();
	}
	
	hatt.stopPropagation();
	});
	
	$("body").click (function(){
		if($(".hat-clik").is(":visible")){
			$(".hat-clik").hide();
		}
	});
	
	$("body").click (function(){
		if($(".menu").is(":visible")){
			$(".menu").hide();
		}
		else{
			$(".menu1").hide();
		}
	});
	
	$("#msg1").click (function(){
		if($(".chat1").is(":hidden")){
			$(".chat1").show();
		}
	});
	
	$("#chat1").click (function(){
			$(".chat1").hide();
	});
	
	$("#pros").click (function(){
			$(".pro").hide();
	});
	
	
	$("#status").click (function(){
		if($(".status-h").is(":hidden")){
			$(".status-h").show();
		} else{
		$(".status-h").hide();
	}
	});
	
	$("#status").hover (function(){
		if($("#btn1").is(":hidden")){
			$("#btn1").show();
		} else{
		$("#btn1").hide();
	}
	});
	
	$("#msg1").hover (function(){
		if($("#btn2").is(":hidden")){
			$("#btn2").show();
		} else{
		$("#btn2").hide();
	}
	});
	
	$("#on").hover (function(){
		if($("#btn3").is(":hidden")){
			$("#btn3").show();
		} else{
		$("#btn3").hide();
	}
	});
	
	$("#dp-m").hover (function(){
		if($(".dp-m").is(":hidden")){
			$(".dp-m").show();
		} else{
		$(".dp-m").hide();
	}
	});
	
	$("#serx").click (function(){
		if($(".serc").is(":hidden")){
			$(".serc").show();
		} else{
		$(".serc").hide();
	}
	});
	
	$("#serc-c").click (function(){
			$(".serc").hide();
	});
	
	$("#arch").click (function(){
		if($(".arch").is(":hidden")){
			$(".arch").show();
		} else{
		$(".arch").hide();
	}
	});
	
	$("#arch-c").click (function(){
			$(".arch").hide();
	});
	
	
	$("#star").click (function(){
		if($(".star").is(":hidden")){
			$(".star").show();
		} else{
		$(".star").hide();
	}
	});
	
	$("#star-c").click (function(){
			$(".star").hide();
	});
	
	$("#setting").click (function(){
		if($(".setting").is(":hidden")){
			$(".setting").show();
		} else{
		$(".setting").hide();
	}
	});
	
	$("#setting-c").click (function(){
			$(".setting").hide();
	});
	
	
	$("#close").click (function(){
			$(".status").hide();
	});
	
	
	$("#pro").click (function(){
		if($(".pro").is(":hidden")){
			$(".pro").show();
		} else{
		$(".pro").hide();
	}
	});
	
	$(".pics").click (function(){
		if($(".profile").is(":hidden")){
			$(".profile").show();
		} else{
		$(".profile").hide();
	}
	});
	
	$("#group").click (function(){
		if($(".group").is(":hidden")){
			$(".group").show();
		} else{
		$(".group").hide();
	}
	});
	
	$("#gro").click (function(){
			$(".group").hide();
	});
	
	$("#crete").click (function(){
		if($(".crete-h").is(":hidden")){
			$(".crete-h").show();
		} else{
		$(".crete-h").hide();
	}
	});
	
	$("#cancel").click (function(){
			$(".crete-h").hide();
	});
	
	$("#profi").click (function(){
		if($(".pro").is(":hidden")){
			$(".pro").show();
		} else{
		$(".pro").hide();
	}
	});
	
	$(document).bind("contextmenu",function(e){
  return false;
    });
	
	
	
	$(".total-chat").contextmenu (function(){
		if($(".menu1").is(":hidden")){
			$(".menu1").show();
		} else{
		$(".menu1").hide();
	}
	});
	
	
	$(".chat").click (function(){
		if($(".hat").is(":hidden")){
			$(".hat").show();
		} 
	});
	
	
	
	$(".chat").click(function(){
		var image=$(this).find("img").prop('src');
		var name=$(this).find("h1").html();
		$(".head-hat>img").attr('src',image);
		$(".name-div>h1").html(name);
	});

	
});










